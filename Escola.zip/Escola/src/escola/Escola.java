package escola;

public class Escola {

    public static void main(String[] args) {
        
    }
    
}
