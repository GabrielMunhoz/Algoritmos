
package escola;


public class Turma {
    private String disciplina;
    private 
}
